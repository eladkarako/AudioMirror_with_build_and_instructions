=-=-=-=-=-=-=-=-=

holds a copy of the files from the build.  
along with devcon.exe

this is a x64 DEBUG build of 
https://github.com/JannesP/AudioMirror

along with a testing certificate.

=-=-=-=-=-=-=-=-=

do not install on your own computer, only a virtual-machine!

this is for testing purposes only.

=-=-=-=-=-=-=-=-=